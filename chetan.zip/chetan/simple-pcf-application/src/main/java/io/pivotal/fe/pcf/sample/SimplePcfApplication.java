package io.pivotal.fe.pcf.sample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimplePcfApplication {

    public static void main(String[] args) {
        SpringApplication.run(SimplePcfApplication.class, args);
    }
}
